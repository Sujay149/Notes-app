from tkinter import *
import pymysql as pm
from tkinter import messagebox
from functions import add_notes, edit_notes, search_notes, delete_notes, sort_notes_alphabetically, sort_notes_by_number

root = Tk()
root.title("Note Taking App")
root.configure(bg='#145660')
root.geometry('1920x1080')

p = Label(root, text='Notespro', height="20", width="40", bg='#145660', fg='white', font=('Helvetica', '18', 'bold', 'italic'))
p.place(x=470, y=90)

def notes():
    note_window = Toplevel(root)
    note_window.title("Add Notes")
    note_window.geometry("1930x1080")
    note_window.configure(bg="black")

    z = Label(note_window, height='22', width="100", bg='#636466', font=('Helvetica', '20', 'italic'))
    z.pack()
    g = Label(note_window, height="2", width="12", bg='#636466', fg="white", text="Create Note ID :", font=('Helvetica', '18', 'italic'))
    g.place(x=400, y=38)
    
    tt = Entry(note_window, bd=5, width='45', font=('Helvetica', '19'))
    tt.place(x=611, y=50)
    txt = Text(note_window, width='80', height='20', font=('Helvetica', '15'))
    txt.place(x=370, y=100)

    def addnotes():
        note_id = int(tt.get())
        note_text = txt.get("1.0", "end-1c")
        add_notes(note_id, note_text)

    butto2 = Button(note_window, text="Save>>", command=addnotes, bg="red", padx=50, pady=10, fg='white', font=('Helvetica', '8', 'bold'))
    butto2.place(x=1080, y=580)
    butto3 = Button(note_window, text="Quit", command=note_window.destroy, bg="red", padx=50, pady=10, fg='white', font=('Helvetica', '8', 'bold'))
    butto3.pack(pady=25)
    
butt1 = Button(root, text="Add New Notes>>", command=notes, bg="red", padx=40, pady=10, bd=7, fg='white', font=('Helvetica', 12, 'bold'))
butt1.place(x=370, y=20)

def ed():
    edit_window = Toplevel(root)
    edit_window.title("Edit Notes")
    edit_window.geometry("1930x1080")
    edit_window.configure(bg="black")

    p = Label(edit_window, height='22', width="100", bg='#636466', font=('Helvetica', '20', 'italic'))
    p.pack()
    q = Label(edit_window, height="2", width="12", bg='#636466', fg="white", text="Enter Note ID :", font=('Helvetica', '18', 'italic'))
    q.place(x=400, y=38)
    
    tt = Entry(edit_window, bd=5, width='45', font=('Helvetica', '19'))
    tt.place(x=611, y=50)
    txt = Text(edit_window, width='80', height='20', font=('Helvetica', '15'))
    txt.place(x=370, y=100)

    def editmsg():
        note_id = int(tt.get())
        note_text = txt.get("1.0", "end-1c")
        edit_notes(note_id, note_text)

    butto2 = Button(edit_window, text="Save>>", command=editmsg, bg="red", padx=50, pady=10, fg='white', font=('Helvetica', '8', 'bold'))
    butto2.place(x=1080, y=580)
    butto3 = Button(edit_window, text="Quit", command=edit_window.destroy, bg="red", padx=50, pady=10, fg='white', font=('Helvetica', '8', 'bold'))
    butto3.pack(pady=25)

but = Button(root, text="Edit Notes>>", command=ed, bg="red", padx=55, pady=10, bd=7, fg='white', font=('Helvetica', 12, 'bold'))
but.place(x=950, y=20)

r = Listbox(root, width='73', height='13', font=('Helvetica', '15'))
r.place(x=370, y=400)

q = Label(root, text='Enter Note ID :', bg='#145660', fg='white', font=('Helvetica', '15', 'bold'))
q.place(x=400, y=220)
s1 = Entry(root, bd=5, width='52', font=('Helvetica', '19'))
s1.place(x=400, y=250)

def search():
    note_id = int(s1.get())
    r.delete(0, END)  # Clear the Listbox before inserting new data
    search_notes(note_id, r)

butt3 = Button(root, text="Search>>", bg="red", padx=25, pady=5, bd=5, fg='white', font=('Helvetica', '10', 'bold'), command=search)
butt3.place(x=610, y=305)

def delete():
    note_id = int(s1.get())
    delete_notes(note_id)

butt4 = Button(root, text="Delete>>", bg="red", padx=25, pady=5, bd=5, fg='white', font=('Helvetica', '10', 'bold'), command=delete)
butt4.place(x=790, y=305)

lab = Label(root, text='List All Notes :', bg='#145660', fg='white', font=('Helvetica', '15', 'bold'))
lab.place(x=700, y=100)

def sortalpha():
    root = Toplevel()
    root.title("List of notes (Sorted in Asc Alphabets)")
    scrollbar = Scrollbar(root)
    scrollbar.pack(side=RIGHT, fill=Y)
    root.geometry("500x800")
    mylist = Listbox(root, width="900", yscrollcommand=scrollbar.set, font=('Helvetica', '15', 'italic'))
    sort_notes_alphabetically(mylist)
    mylist.pack(side=LEFT, fill=BOTH)
    scrollbar.config(command=mylist.yview)
    root.mainloop()

bu = Button(root, text="By Alphabets >>", bg="red", padx=25, pady=5, bd=5, fg='white', font=('Helvetica', '10', 'bold'), command=sortalpha)
bu.place(x=530, y=150)

def sortnum():
    root = Toplevel()
    root.title("List of notes (Sorted in ASC Numbers)")
    scrollbar = Scrollbar(root)
    scrollbar.pack(side=RIGHT, fill=Y)
    root.geometry("500x800")
    mylist = Listbox(root, width="900", yscrollcommand=scrollbar.set, font=('Helvetica', '15', 'italic'))
    sort_notes_by_number(mylist)
    mylist.pack(side=LEFT, fill=BOTH)
    scrollbar.config(command=mylist.yview)
    root.mainloop()

bu1 = Button(root, text="By Numbers >>", bg="red", padx=25, pady=5, bd=5, fg='white', font=('Helvetica', '10', 'bold'), command=sortnum)
bu1.place(x=820, y=150)

butt6 = Button(root, text="Exit", command=root.destroy, bg="red", fg='white', padx=50, pady=10, bd=5, font=('Helvetica', '10', 'bold'))
butt6.place(x=710, y=750)

root.mainloop()