import pymysql as pm
from tkinter import messagebox

def add_notes(note_id, note_text):
    try:
        con = pm.connect(host="localhost", database='Notespro', user='root', password='')
        cursor = con.cursor()
        query_insert = "INSERT INTO test (id, text) VALUES (%s, %s)"
        cursor.execute(query_insert, (note_id, note_text))
        con.commit()
        messagebox.showinfo("Success", "Note added successfully!")
    except pm.MySQLError as e:
        messagebox.showerror("Database Error", str(e))
        if con:
            con.rollback()
    finally:
        if cursor:
            cursor.close()
        if con:
            con.close()

def edit_notes(note_id, note_text):
    try:
        con = pm.connect(host="localhost", database='Notespro', user='root', password='')
        cursor = con.cursor()
        query_update = "UPDATE test SET text=%s WHERE id=%s"
        cursor.execute(query_update, (note_text, note_id))
        con.commit()
        messagebox.showinfo("Success", "Note updated successfully!")
    except pm.MySQLError as e:
        messagebox.showerror("Database Error", str(e))
        if con:
            con.rollback()
    finally:
        if cursor:
            cursor.close()
        if con:
            con.close()

def search_notes(note_id, listbox):
    try:
        con = pm.connect(host="localhost", database='Notespro', user='root', password='')
        cursor = con.cursor()
        searchquery = "SELECT * FROM test WHERE id=%s"
        cursor.execute(searchquery, (note_id,))
        data = cursor.fetchone()
        listbox.insert(END, data)
        con.commit()
    except pm.MySQLError as e:
        messagebox.showerror("Database Error", str(e))
        if con:
            con.rollback()
    finally:
        if cursor:
            cursor.close()
        if con:
            con.close()

def delete_notes(note_id):
    try:
        con = pm.connect(host="localhost", database='Notespro', user='root', password='')
        cursor = con.cursor()
        deletequery = "DELETE FROM test WHERE id=%s"
        cursor.execute(deletequery, (note_id,))
        con.commit()
        messagebox.showinfo("Success", "Note deleted successfully!")
    except pm.MySQLError as e:
        messagebox.showerror("Database Error", str(e))
        if con:
            con.rollback()
    finally:
        if cursor:
            cursor.close()
        if con:
            con.close()

def sort_notes_alphabetically(listbox):
    try:
        con = pm.connect(host="localhost", database='Notespro', user='root', password='')
        cursor = con.cursor()
        query_sort = "SELECT * FROM test ORDER BY text ASC"
        cursor.execute(query_sort)
        data = cursor.fetchall()
        for item in data:
            listbox.insert(END, item)
        con.commit()
    except pm.MySQLError as e:
        messagebox.showerror("Database Error", str(e))
        if con:
            con.rollback()
    finally:
        if cursor:
            cursor.close()
        if con:
            con.close()

def sort_notes_by_number(listbox):
    try:
        con = pm.connect(host="localhost", database='Notespro', user='root', password='')
        cursor = con.cursor()
        query_sort = "SELECT * FROM test ORDER BY id ASC"
        cursor.execute(query_sort)
        data = cursor.fetchall()
        for item in data:
            listbox.insert(END, item)
        con.commit()
    except pm.MySQLError as e:
        messagebox.showerror("Database Error", str(e))
        if con:
            con.rollback()
    finally:
        if cursor:
            cursor.close()
        if con:
            con.close()
